package com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer;

public enum Rarity {
    COMMON,
    UNCOMMON,
    RARE,
    EPIC,
    LEGENDARY
}