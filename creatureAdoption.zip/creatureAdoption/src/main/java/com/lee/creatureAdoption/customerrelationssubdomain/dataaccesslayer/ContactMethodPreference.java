package com.lee.creatureAdoption.customerrelationssubdomain.dataaccesslayer;

public enum ContactMethodPreference {
    EMAIL,
    PHONE,
    TEXT
}
