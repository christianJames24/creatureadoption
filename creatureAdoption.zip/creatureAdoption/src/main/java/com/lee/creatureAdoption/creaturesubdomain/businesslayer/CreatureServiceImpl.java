package com.lee.creatureAdoption.creaturesubdomain.businesslayer;

import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.Creature;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureIdentifier;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureRepository;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureTraits;
import com.lee.creatureAdoption.creaturesubdomain.mappinglayer.CreatureRequestMapper;
import com.lee.creatureAdoption.creaturesubdomain.mappinglayer.CreatureResponseMapper;
import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureRequestModel;
import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureResponseModel;
import com.lee.creatureAdoption.utils.exceptions.InvalidInputException;
import com.lee.creatureAdoption.utils.exceptions.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CreatureServiceImpl implements CreatureService {

    private final CreatureRepository creatureRepository;
    private final CreatureResponseMapper creatureResponseMapper;
    private final CreatureRequestMapper creatureRequestMapper;

    public CreatureServiceImpl(CreatureRepository creatureRepository, CreatureResponseMapper creatureResponseMapper, CreatureRequestMapper creatureRequestMapper) {
        this.creatureRepository = creatureRepository;
        this.creatureResponseMapper = creatureResponseMapper;
        this.creatureRequestMapper = creatureRequestMapper;
    }

    @Override
    public List<CreatureResponseModel> getCreatures(Map<String, String> queryParams) {
        List<Creature> creatures = creatureRepository.findAll();

        String creatureId = queryParams.get("creatureId");
        String name = queryParams.get("name");
        String species = queryParams.get("species");
        String type = queryParams.get("type");
        String rarity = queryParams.get("rarity");
        String status = queryParams.get("status");

        if (type != null && !type.isEmpty()) {
            creatures = creatures.stream()
                    .filter(c -> c.getType() != null &&
                            c.getType().toString().equalsIgnoreCase(type))
                    .collect(Collectors.toList());
        }
        if (rarity != null && !rarity.isEmpty()) {
            creatures = creatures.stream()
                    .filter(c -> c.getRarity() != null &&
                            c.getRarity().toString().equalsIgnoreCase(rarity))
                    .collect(Collectors.toList());
        }
        if (status != null && !status.isEmpty()) {
            creatures = creatures.stream()
                    .filter(c -> c.getStatus() != null &&
                            c.getStatus().toString().equalsIgnoreCase(status))
                    .collect(Collectors.toList());
        }

        return creatureResponseMapper.entityListToResponseModelList(creatures);
    }

    @Override
    public CreatureResponseModel getCreatureByCreatureId(String creatureId) {
        Creature creature = creatureRepository.findByCreatureIdentifier_CreatureId(creatureId);

        if (creature == null) {
            throw new NotFoundException("Provided creatureId not found: " + creatureId);
        }
        return creatureResponseMapper.entityToResponseModel(creature);
    }

    @Override
    public CreatureResponseModel addCreature(CreatureRequestModel creatureRequestModel) {
        CreatureTraits traits = new CreatureTraits(
                creatureRequestModel.getStrength(),
                creatureRequestModel.getIntelligence(),
                creatureRequestModel.getAgility(),
                creatureRequestModel.getTemperament()
        );

        Creature creature = creatureRequestMapper.requestModelToEntity(creatureRequestModel, new CreatureIdentifier(), traits);

        creature.setCreatureTraits(traits);
        return creatureResponseMapper.entityToResponseModel(creatureRepository.save(creature));
    }

    @Override
    public CreatureResponseModel updateCreature(CreatureRequestModel creatureRequestModel, String creatureId) {
        Creature existingCreature = creatureRepository.findByCreatureIdentifier_CreatureId(creatureId);

        if (existingCreature == null) {
            throw new NotFoundException("Provided creatureId not found: " + creatureId);
        }

        CreatureTraits traits = new CreatureTraits(
                creatureRequestModel.getStrength(),
                creatureRequestModel.getIntelligence(),
                creatureRequestModel.getAgility(),
                creatureRequestModel.getTemperament()
        );

        Creature updatedCreature = creatureRequestMapper.requestModelToEntity(creatureRequestModel,
                existingCreature.getCreatureIdentifier(), traits);
        updatedCreature.setId(existingCreature.getId());

        Creature response = creatureRepository.save(updatedCreature);
        return creatureResponseMapper.entityToResponseModel(response);
    }

    @Override
    public void removeCreature(String creatureId) {
        Creature existingCreature = creatureRepository.findByCreatureIdentifier_CreatureId(creatureId);

        if (existingCreature == null) {
            throw new NotFoundException("Provided creatureId not found: " + creatureId);
        }

        creatureRepository.delete(existingCreature);
    }
}