package com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer;

import jakarta.persistence.Embeddable;
import lombok.Getter;

import java.util.UUID;

@Embeddable
@Getter
public class AdoptionIdentifier {

    private String adoptionId;
    private String adoptionCode;

    public AdoptionIdentifier() {
        this.adoptionId = UUID.randomUUID().toString();
        this.adoptionCode = "ADO-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public AdoptionIdentifier(String adoptionId, String adoptionCode) {
        this.adoptionId = adoptionId;
        this.adoptionCode = adoptionCode;
    }
}