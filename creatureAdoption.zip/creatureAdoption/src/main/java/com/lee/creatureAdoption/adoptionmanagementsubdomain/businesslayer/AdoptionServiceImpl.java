package com.lee.creatureAdoption.adoptionmanagementsubdomain.businesslayer;

import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.Adoption;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.AdoptionIdentifier;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.AdoptionRepository;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.AdoptionStatus;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.mappinglayer.AdoptionRequestMapper;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.mappinglayer.AdoptionResponseMapper;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionRequestModel;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionResponseModel;
import com.lee.creatureAdoption.creaturesubdomain.businesslayer.CreatureService;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureStatus;
import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureRequestModel;
import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureResponseModel;
import com.lee.creatureAdoption.customerrelationssubdomain.businesslayer.CustomerService;
import com.lee.creatureAdoption.customerrelationssubdomain.presentationlayer.CustomerResponseModel;
import com.lee.creatureAdoption.trainingsubdomain.businesslayer.TrainingService;
import com.lee.creatureAdoption.trainingsubdomain.presentationlayer.TrainingResponseModel;
import com.lee.creatureAdoption.utils.exceptions.InvalidInputException;
import com.lee.creatureAdoption.utils.exceptions.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AdoptionServiceImpl implements AdoptionService {

    private static final int MAX_ADOPTIONS_PER_CUSTOMER = 2;

    private final AdoptionRepository adoptionRepository;
    private final AdoptionResponseMapper adoptionResponseMapper;
    private final AdoptionRequestMapper adoptionRequestMapper;
    private final CustomerService customerService;
    private final CreatureService creatureService;
    private final TrainingService trainingService;

    @Autowired
    public AdoptionServiceImpl(AdoptionRepository adoptionRepository,
                               AdoptionResponseMapper adoptionResponseMapper,
                               AdoptionRequestMapper adoptionRequestMapper,
                               CustomerService customerService,
                               CreatureService creatureService, TrainingService trainingService) {
        this.adoptionRepository = adoptionRepository;
        this.adoptionResponseMapper = adoptionResponseMapper;
        this.adoptionRequestMapper = adoptionRequestMapper;
        this.customerService = customerService;
        this.creatureService = creatureService;
        this.trainingService = trainingService;
    }

    @Override
    public List<AdoptionResponseModel> getAdoptions(Map<String, String> queryParams) {
        List<Adoption> adoptions = adoptionRepository.findAll();

        String customerId = queryParams.get("customerId");
        String creatureId = queryParams.get("creatureId");
        String profileStatus = queryParams.get("profileStatus");
        String adoptionStatus = queryParams.get("adoptionStatus");

        if (customerId != null && !customerId.isEmpty()) {
            adoptions = adoptions.stream()
                    .filter(a -> a.getCustomerId() != null &&
                            a.getCustomerId().equals(customerId))
                    .collect(Collectors.toList());
        }
        if (creatureId != null && !creatureId.isEmpty()) {
            adoptions = adoptions.stream()
                    .filter(a -> a.getCreatureId() != null &&
                            a.getCreatureId().equals(creatureId))
                    .collect(Collectors.toList());
        }
        if (profileStatus != null && !profileStatus.isEmpty()) {
            adoptions = adoptions.stream()
                    .filter(a -> a.getProfileStatus() != null &&
                            a.getProfileStatus().toString().equalsIgnoreCase(profileStatus))
                    .collect(Collectors.toList());
        }
        if (adoptionStatus != null && !adoptionStatus.isEmpty()) {
            adoptions = adoptions.stream()
                    .filter(a -> a.getAdoptionStatus() != null &&
                            a.getAdoptionStatus().toString().equalsIgnoreCase(adoptionStatus))
                    .collect(Collectors.toList());
        }

        List<AdoptionResponseModel> responseModels = adoptionResponseMapper.entityListToResponseModelList(adoptions);

        // Apply additional details to each response model
        for (int i = 0; i < adoptions.size(); i++) {
            populateAdditionalDetails(responseModels.get(i), adoptions.get(i));
        }

        return responseModels;
    }

    @Override
    public AdoptionResponseModel getAdoptionByAdoptionId(String adoptionId) {
        Adoption adoption = adoptionRepository.findByAdoptionIdentifier_AdoptionId(adoptionId);

        if (adoption == null) {
            throw new NotFoundException("Provided adoptionId not found: " + adoptionId);
        }

        AdoptionResponseModel responseModel = adoptionResponseMapper.entityToResponseModel(adoption);
        populateAdditionalDetails(responseModel, adoption);

        return responseModel;
    }

    @Override
    @Transactional
    public AdoptionResponseModel addAdoption(AdoptionRequestModel adoptionRequestModel) {
        CustomerResponseModel customer = customerService.getCustomerByCustomerId(adoptionRequestModel.getCustomerId());
        if (customer == null) {
            throw new NotFoundException("Customer not found with ID: " + adoptionRequestModel.getCustomerId());
        }

        CreatureResponseModel creature = creatureService.getCreatureByCreatureId(adoptionRequestModel.getCreatureId());
        if (creature == null) {
            throw new NotFoundException("Creature not found with ID: " + adoptionRequestModel.getCreatureId());
        }

        if (creature.getStatus() != CreatureStatus.AVAILABLE &&
                creature.getStatus() != CreatureStatus.RESERVED) {
            throw new InvalidInputException("Creature is not available for adoption. Current status: " + creature.getStatus());
        }

        //count completed adoptions for current adoptions
        Integer currentAdoptions = (int) adoptionRepository.findAll().stream()
                .filter(a -> a.getCustomerId().equals(adoptionRequestModel.getCustomerId()) &&
                        a.getAdoptionStatus() == AdoptionStatus.COMPLETED)
                .count();

        //aggregate 2: if over max adoptions per customers then invalidinputexception
        if (currentAdoptions >= MAX_ADOPTIONS_PER_CUSTOMER) {
            throw new InvalidInputException("Customer has reached the maximum limit of " + MAX_ADOPTIONS_PER_CUSTOMER + " adoptions");
        }

        Adoption adoption = adoptionRequestMapper.requestModelToEntity(adoptionRequestModel, new AdoptionIdentifier());

        if (adoption.getAdoptionStatus() == null) {
            adoption.setAdoptionStatus(AdoptionStatus.PENDING);
        }
        adoption.setAdoptionStatus(AdoptionStatus.PENDING);

        updateCreatureStatus(adoptionRequestModel.getCreatureId(), adoption.getAdoptionStatus());

        Adoption savedAdoption = adoptionRepository.save(adoption);
        AdoptionResponseModel responseModel = adoptionResponseMapper.entityToResponseModel(savedAdoption);
        populateAdditionalDetails(responseModel, savedAdoption);

        return responseModel;
    }

    @Override
    @Transactional
    public AdoptionResponseModel updateAdoption(AdoptionRequestModel adoptionRequestModel, String adoptionId) {
        Adoption existingAdoption = adoptionRepository.findByAdoptionIdentifier_AdoptionId(adoptionId);

        if (existingAdoption == null) {
            throw new NotFoundException("Provided adoptionId not found: " + adoptionId);
        }

        AdoptionStatus previousStatus = existingAdoption.getAdoptionStatus();

        Adoption updatedAdoption = adoptionRequestMapper.requestModelToEntity(adoptionRequestModel,
                existingAdoption.getAdoptionIdentifier());
        updatedAdoption.setId(existingAdoption.getId());
        updatedAdoption.setLastUpdated(LocalDateTime.now());

        if (previousStatus != updatedAdoption.getAdoptionStatus()) {
            updateCreatureStatus(updatedAdoption.getCreatureId(), updatedAdoption.getAdoptionStatus());
        }

        Adoption savedAdoption = adoptionRepository.save(updatedAdoption);
        AdoptionResponseModel responseModel = adoptionResponseMapper.entityToResponseModel(savedAdoption);
        populateAdditionalDetails(responseModel, savedAdoption);

        return responseModel;
    }

    @Override
    @Transactional
    public AdoptionResponseModel updateAdoptionStatus(String adoptionId, String newStatusStr) {
        Adoption existingAdoption = adoptionRepository.findByAdoptionIdentifier_AdoptionId(adoptionId);

        if (existingAdoption == null) {
            throw new NotFoundException("Provided adoptionId not found: " + adoptionId);
        }

        try {
            AdoptionStatus newStatus = AdoptionStatus.valueOf(newStatusStr.toUpperCase());
            AdoptionStatus previousStatus = existingAdoption.getAdoptionStatus();

            existingAdoption.setAdoptionStatus(newStatus);
            existingAdoption.setLastUpdated(LocalDateTime.now());

            updateCreatureStatus(existingAdoption.getCreatureId(), newStatus);

            Adoption savedAdoption = adoptionRepository.save(existingAdoption);
            AdoptionResponseModel responseModel = adoptionResponseMapper.entityToResponseModel(savedAdoption);
            populateAdditionalDetails(responseModel, savedAdoption);

            return responseModel;
        } catch (IllegalArgumentException e) {
            throw new InvalidInputException("Invalid adoption status: " + newStatusStr);
        }
    }

    @Override
    @Transactional
    public void removeAdoption(String adoptionId) {
        Adoption existingAdoption = adoptionRepository.findByAdoptionIdentifier_AdoptionId(adoptionId);

        if (existingAdoption == null) {
            throw new NotFoundException("Provided adoptionId not found: " + adoptionId);
        }


        if (existingAdoption.getAdoptionStatus() == AdoptionStatus.COMPLETED) {
            throw new InvalidInputException("Cannot remove a completed adoption. Please update status to CANCELLED or RETURNED first.");
        }

        updateCreatureStatus(existingAdoption.getCreatureId(), AdoptionStatus.CANCELLED);

        adoptionRepository.delete(existingAdoption);
    }

    //handler for aggregate 1, bascially wat happens is that the update creature status like is called every time theres a change and basicakky updates the creature based on hte adoption status to keep the creature consistent with it
    private void updateCreatureStatus(String creatureId, AdoptionStatus adoptionStatus) {
        CreatureResponseModel creature = creatureService.getCreatureByCreatureId(creatureId);
        if (creature == null) {
            throw new NotFoundException("Creature not found with ID: " + creatureId);
        }

        CreatureStatus newCreatureStatus;

        switch (adoptionStatus) {
            case PENDING:
                newCreatureStatus = CreatureStatus.ADOPTION_PENDING;
                break;
            case APPROVED:
                newCreatureStatus = CreatureStatus.RESERVED;
                break;
            case COMPLETED:
                newCreatureStatus = CreatureStatus.ADOPTED;
                break;
            case CANCELLED:
            case RETURNED:
                newCreatureStatus = CreatureStatus.AVAILABLE;
                break;
            default:
                throw new InvalidInputException("Unsupported adoption status: " + adoptionStatus);
        }

        if (creature.getStatus() != newCreatureStatus) {
            CreatureRequestModel creatureRequestModel = CreatureRequestModel.builder()
                    .name(creature.getName())
                    .species(creature.getSpecies())
                    .type(creature.getType())
                    .rarity(creature.getRarity())
                    .level(creature.getLevel())
                    .age(creature.getAge())
                    .health(creature.getHealth())
                    .experience(creature.getExperience())
                    .status(newCreatureStatus)
                    .strength(creature.getStrength())
                    .intelligence(creature.getIntelligence())
                    .agility(creature.getAgility())
                    .temperament(creature.getTemperament())
                    .build();

            creatureService.updateCreature(creatureRequestModel, creatureId);
            //update the creature status based on adoption status
            //public enum CreatureStatus {
            //    AVAILABLE,
            //    ADOPTION_PENDING,
            //    ADOPTED,
            //    RESERVED,
            //    UNAVAILABLE
            //}
        }
    }

    private void populateAdditionalDetails(AdoptionResponseModel response, Adoption adoption) { //is important or else first name and stuff will be null, remember is reference to customer with customerid
        CustomerResponseModel customer = customerService.getCustomerByCustomerId(adoption.getCustomerId());
        if (customer != null) {
            response.setCustomerFirstName(customer.getFirstName());
            response.setCustomerLastName(customer.getLastName());
        }

        CreatureResponseModel creature = creatureService.getCreatureByCreatureId(adoption.getCreatureId());
        if (creature != null) {
            response.setCreatureName(creature.getName());
            response.setCreatureSpecies(creature.getSpecies());
            response.setCreatureStatus(creature.getStatus());
        }

        //i think in data i accidentally have like a training id that doesnt exist for a customer so i hav to do this or else i get training not found error
        if (adoption.getTrainingId() != null) {
            TrainingResponseModel training = trainingService.getTrainingByTrainingId(adoption.getTrainingId());
            if (training != null) {
                response.setTrainingName(training.getName());
                response.setTrainingLocation(training.getLocation());
            }
        } else {
            response.setTrainingName(null);
            response.setTrainingLocation(null);
        }
    }
}