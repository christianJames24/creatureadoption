package com.lee.creatureAdoption.creaturesubdomain.businesslayer;

import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureRequestModel;
import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureResponseModel;

import java.util.List;
import java.util.Map;

public interface CreatureService {

    List<CreatureResponseModel> getCreatures(Map<String, String> queryParams);
    CreatureResponseModel getCreatureByCreatureId(String creatureId);
    CreatureResponseModel addCreature(CreatureRequestModel creatureRequestModel);
    CreatureResponseModel updateCreature(CreatureRequestModel updatedCreature, String creatureId);
    void removeCreature(String creatureId);
}