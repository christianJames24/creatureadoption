package com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer;

public enum AdoptionStatus {
    PENDING,
    APPROVED,
    COMPLETED,
    CANCELLED,
    RETURNED
}