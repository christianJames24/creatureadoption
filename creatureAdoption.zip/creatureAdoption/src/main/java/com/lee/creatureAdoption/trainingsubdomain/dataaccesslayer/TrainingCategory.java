package com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer;

public enum TrainingCategory {
    ATTACK,
    DEFENSE,
    CONTEST,
    SPECIAL
}