package com.lee.creatureAdoption.adoptionmanagementsubdomain.mappinglayer;

import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.Adoption;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.AdoptionIdentifier;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionRequestModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface AdoptionRequestMapper {

    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(target = "lastUpdated", expression = "java(java.time.LocalDateTime.now())")
    })
    Adoption requestModelToEntity(AdoptionRequestModel adoptionRequestModel, AdoptionIdentifier adoptionIdentifier);
}