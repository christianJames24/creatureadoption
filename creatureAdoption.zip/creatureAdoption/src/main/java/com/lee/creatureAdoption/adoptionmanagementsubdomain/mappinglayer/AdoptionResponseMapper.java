package com.lee.creatureAdoption.adoptionmanagementsubdomain.mappinglayer;

import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.Adoption;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionController;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionResponseModel;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.springframework.hateoas.Link;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Mapper(componentModel = "spring")
public interface AdoptionResponseMapper {

    @Mapping(expression = "java(adoption.getAdoptionIdentifier().getAdoptionId())", target = "adoptionId")
    @Mapping(expression = "java(adoption.getAdoptionIdentifier().getAdoptionCode())", target = "adoptionCode")
    AdoptionResponseModel entityToResponseModel(Adoption adoption);

    List<AdoptionResponseModel> entityListToResponseModelList(List<Adoption> adoptions);

    @AfterMapping
    default void addLinks(@MappingTarget AdoptionResponseModel response, Adoption adoption) {
        Link selfLink = linkTo(methodOn(AdoptionController.class)
                .getAdoptionByAdoptionId(response.getAdoptionId()))
                .withSelfRel();
        response.add(selfLink);

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("adoptionId", response.getAdoptionId());

        Link allAdoptionsLink = linkTo(methodOn(AdoptionController.class)
                .getAdoptions(queryParams))
                .withRel("allAdoptions");
        response.add(allAdoptionsLink);

        Link customerLink = linkTo(methodOn(com.lee.creatureAdoption.customerrelationssubdomain.presentationlayer.CustomerController.class)
                .getCustomerByCustomerId(response.getCustomerId()))
                .withRel("customer");
        response.add(customerLink);

        Link creatureLink = linkTo(methodOn(com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureController.class)
                .getCreatureByCreatureId(response.getCreatureId()))
                .withRel("creature");
        response.add(creatureLink);
    }
}