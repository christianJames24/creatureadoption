package com.lee.creatureAdoption.customerrelationssubdomain.dataaccesslayer;

/**
 * @author Christine Gerard
 * @created 02/11/2024
 * @project cardealership-ws-2024
 */
public enum PhoneType {

    HOME,
    WORK,
    MOBILE
}
