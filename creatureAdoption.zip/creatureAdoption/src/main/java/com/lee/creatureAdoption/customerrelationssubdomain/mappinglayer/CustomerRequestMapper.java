package com.lee.creatureAdoption.customerrelationssubdomain.mappinglayer;

import com.lee.creatureAdoption.customerrelationssubdomain.dataaccesslayer.Customer;
import com.lee.creatureAdoption.customerrelationssubdomain.dataaccesslayer.CustomerAddress;
import com.lee.creatureAdoption.customerrelationssubdomain.dataaccesslayer.CustomerIdentifier;
import com.lee.creatureAdoption.customerrelationssubdomain.presentationlayer.CustomerRequestModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface CustomerRequestMapper {

    @Mappings({
        @Mapping(target = "id", ignore = true),
    })
    Customer requestModelToEntity(CustomerRequestModel customerRequestModel, CustomerIdentifier customerIdentifier,
                                  CustomerAddress customerAddress);
}
