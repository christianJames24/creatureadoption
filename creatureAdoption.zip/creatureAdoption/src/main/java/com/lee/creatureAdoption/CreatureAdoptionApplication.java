package com.lee.creatureAdoption;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreatureAdoptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreatureAdoptionApplication.class, args);
	}

}
