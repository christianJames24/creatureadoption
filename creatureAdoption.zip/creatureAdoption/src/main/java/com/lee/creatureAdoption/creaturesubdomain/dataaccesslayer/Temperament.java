package com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer;

public enum Temperament {
    DOCILE,
    FRIENDLY,
    AGGRESSIVE,
    TIMID,
    PLAYFUL
}