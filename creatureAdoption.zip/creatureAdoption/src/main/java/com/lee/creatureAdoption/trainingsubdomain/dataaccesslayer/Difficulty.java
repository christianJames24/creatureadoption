package com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer;

public enum Difficulty {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}