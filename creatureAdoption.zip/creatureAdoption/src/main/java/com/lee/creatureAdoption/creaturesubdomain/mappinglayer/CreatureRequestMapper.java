package com.lee.creatureAdoption.creaturesubdomain.mappinglayer;

import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.Creature;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureIdentifier;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureTraits;
import com.lee.creatureAdoption.creaturesubdomain.presentationlayer.CreatureRequestModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface CreatureRequestMapper {

    @Mappings({
            @Mapping(target = "id", ignore = true),
    })
    Creature requestModelToEntity(CreatureRequestModel creatureRequestModel, CreatureIdentifier creatureIdentifier,
                                  CreatureTraits creatureTraits);
}