package com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer;

public enum ProfileStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}