package com.lee.creatureAdoption.trainingsubdomain.businesslayer;

import com.lee.creatureAdoption.trainingsubdomain.presentationlayer.TrainingRequestModel;
import com.lee.creatureAdoption.trainingsubdomain.presentationlayer.TrainingResponseModel;

import java.util.List;
import java.util.Map;

public interface TrainingService {

    List<TrainingResponseModel> getTrainings(Map<String, String> queryParams);
    TrainingResponseModel getTrainingByTrainingId(String trainingId);
    TrainingResponseModel addTraining(TrainingRequestModel trainingRequestModel);
    TrainingResponseModel updateTraining(TrainingRequestModel updatedTraining, String trainingId);
    void removeTraining(String trainingId);
}