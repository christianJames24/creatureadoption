package com.lee.creatureAdoption.creaturesubdomain.presentationlayer;

import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureStatus;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureType;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.Rarity;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.Temperament;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class CreatureRequestModel {

    String name;
    String species;
    CreatureType type;
    Rarity rarity;
    Integer level;
    Integer age;
    Integer health;
    Integer experience;
    CreatureStatus status;
    Integer strength;
    Integer intelligence;
    Integer agility;
    Temperament temperament;
}