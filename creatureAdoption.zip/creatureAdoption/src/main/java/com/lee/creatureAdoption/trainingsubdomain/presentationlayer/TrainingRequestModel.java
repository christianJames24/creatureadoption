package com.lee.creatureAdoption.trainingsubdomain.presentationlayer;

import com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer.Difficulty;
import com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer.TrainingStatus;
import com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer.TrainingCategory;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class TrainingRequestModel {

    String name;
    String description;
    Difficulty difficulty;
    Integer duration;
    TrainingStatus status;
    TrainingCategory category;
    Double price;
    String location;
}