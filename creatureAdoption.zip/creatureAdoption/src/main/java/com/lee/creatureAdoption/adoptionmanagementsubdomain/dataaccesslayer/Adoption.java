package com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.antlr.v4.runtime.misc.NotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="adoptions")
@Data
@NoArgsConstructor
public class Adoption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Embedded
    private AdoptionIdentifier adoptionIdentifier;

    private String summary;
    private Integer totalAdoptions;
    private LocalDate profileCreationDate;
    private LocalDateTime lastUpdated;

    @Enumerated(EnumType.STRING)
    private ProfileStatus profileStatus;

    private LocalDate adoptionDate;
    private String adoptionLocation;

    @Enumerated(EnumType.STRING)
    private AdoptionStatus adoptionStatus;

    private String specialNotes;

    //ids from other suddomains because it aggregate
    private String customerId;
    private String creatureId;
    private String trainingId;

    public Adoption(@NotNull String summary, @NotNull Integer totalAdoptions,
                    @NotNull LocalDate profileCreationDate, @NotNull ProfileStatus profileStatus,
                    @NotNull LocalDate adoptionDate, @NotNull String adoptionLocation,
                    @NotNull AdoptionStatus adoptionStatus, String specialNotes,
                    @NotNull String customerId, @NotNull String creatureId, String trainingId) {

        this.adoptionIdentifier = new AdoptionIdentifier();
        this.summary = summary;
        this.totalAdoptions = totalAdoptions;
        this.profileCreationDate = profileCreationDate;
        this.lastUpdated = LocalDateTime.now();
        this.profileStatus = profileStatus;
        this.adoptionDate = adoptionDate;
        this.adoptionLocation = adoptionLocation;
        this.adoptionStatus = adoptionStatus;
        this.specialNotes = specialNotes;
        this.customerId = customerId;
        this.creatureId = creatureId;
        this.trainingId = trainingId;
    }
}