package com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer;

import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.AdoptionStatus;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer.ProfileStatus;
import com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer.CreatureStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public final class AdoptionResponseModel extends RepresentationModel<AdoptionResponseModel> {

    String adoptionId;
    String adoptionCode;
    String summary;
    Integer totalAdoptions;
    LocalDate profileCreationDate;
    LocalDateTime lastUpdated;
    ProfileStatus profileStatus;
    LocalDate adoptionDate;
    String adoptionLocation;
    AdoptionStatus adoptionStatus;
    String specialNotes;


    String customerId;
    String customerFirstName;
    String customerLastName;

    String creatureId;
    String creatureName;
    String creatureSpecies;
    CreatureStatus creatureStatus;

    String trainingId;
    String trainingName;
    String trainingLocation;
}