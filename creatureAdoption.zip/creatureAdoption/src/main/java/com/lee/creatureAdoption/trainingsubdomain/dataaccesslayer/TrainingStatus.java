package com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer;

public enum TrainingStatus {
    ACTIVE,
    INACTIVE,
    FULL
}