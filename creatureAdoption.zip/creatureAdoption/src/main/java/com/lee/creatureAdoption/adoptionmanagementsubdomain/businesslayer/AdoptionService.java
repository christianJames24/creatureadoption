package com.lee.creatureAdoption.adoptionmanagementsubdomain.businesslayer;

import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionRequestModel;
import com.lee.creatureAdoption.adoptionmanagementsubdomain.presentationlayer.AdoptionResponseModel;

import java.util.List;
import java.util.Map;

public interface AdoptionService {

    List<AdoptionResponseModel> getAdoptions(Map<String, String> queryParams);
    AdoptionResponseModel getAdoptionByAdoptionId(String adoptionId);
    AdoptionResponseModel addAdoption(AdoptionRequestModel adoptionRequestModel);
    AdoptionResponseModel updateAdoption(AdoptionRequestModel updatedAdoption, String adoptionId);
    AdoptionResponseModel updateAdoptionStatus(String adoptionId, String newStatus);
    void removeAdoption(String adoptionId);
}