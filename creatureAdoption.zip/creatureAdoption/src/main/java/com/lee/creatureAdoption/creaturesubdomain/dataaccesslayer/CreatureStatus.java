package com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer;

public enum CreatureStatus {
    AVAILABLE,
    ADOPTION_PENDING,
    ADOPTED,
    RESERVED,
    UNAVAILABLE
}