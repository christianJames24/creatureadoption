package com.lee.creatureAdoption.creaturesubdomain.dataaccesslayer;

public enum CreatureType { //just the pokemon types lol 🙂🙂
    NORMAL,
    FIRE,
    WATER,
    GRASS,
    ELECTRIC,
    ICE,
    FIGHTING,
    POISON,
    GROUND,
    FLYING,
    PSYCHIC,
    BUG,
    ROCK,
    GHOST,
    DRAGON,
    DARK,
    STEEL,
    FAIRY
}