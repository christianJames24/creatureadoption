package com.lee.creatureAdoption.trainingsubdomain.mappinglayer;

import com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer.Training;
import com.lee.creatureAdoption.trainingsubdomain.dataaccesslayer.TrainingIdentifier;
import com.lee.creatureAdoption.trainingsubdomain.presentationlayer.TrainingRequestModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface TrainingRequestMapper {

    @Mappings({
            @Mapping(target = "id", ignore = true),
    })
    Training requestModelToEntity(TrainingRequestModel trainingRequestModel, TrainingIdentifier trainingIdentifier);
}