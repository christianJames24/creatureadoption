package com.lee.creatureAdoption.adoptionmanagementsubdomain.dataaccesslayer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AdoptionRepository extends JpaRepository<Adoption, Integer> {

    Adoption findByAdoptionIdentifier_AdoptionId(String adoptionId);
}