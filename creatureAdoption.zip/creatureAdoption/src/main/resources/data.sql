INSERT INTO customers (customer_id, first_name, last_name, email_address, contact_method_preference, street_address, city, province, country, postal_code)
VALUES
    ('6f8d2e53-9b4c-48a7-91fe-c508dde7817a', 'Burgh', 'Arty', 'gym.leader@castelia.com', 'EMAIL', '123 Gallery St', 'Castelia City', 'UNOVA', 'United States', 'U2X 1Y2'),
    ('a3b7c9d1-e5f0-4a2b-8c9d-0e1f2a3b4c5d', 'Roark', 'Toichi', 'mining.leader@oreburgh.com', 'PHONE', '456 Coal Ave', 'Jubilife City', 'SINNOH', 'Japan', 'S4B 1B3'),
    ('7d8e9f0a-1b2c-3d4e-5f6a-7b8c9d0e1f2a', 'Elesa', 'Kamitsure', 'electrifying@nimbasagym.com', 'TEXT', '789 Runway Rd', 'Nimbasa Town', 'UNOVA', 'United States', 'U5K 0A1'),
    ('2a3b4c5d-6e7f-8a9b-0c1d-2e3f4a5b6c7d', 'Maylene', 'Sumomo', 'fighting.spirit@veilstone.com', 'EMAIL', '101 Dojo Ln', 'Veilstone City', 'SINNOH', 'Japan', 'S2P 2G8'),
    ('8e9f0a1b-2c3d-4e5f-6a7b-8c9d0e1f2a3b', 'N', 'Harmonia', 'natural.friend@plasma.com', 'PHONE', '202 Liberation Dr', 'Accumula Town', 'UNOVA', 'United States', 'U1P 5G4'),
    ('4c5d6e7f-8a9b-0c1d-2e3f-4a5b6c7d8e9f', 'Caitlin', 'Cattleya', 'psychic.dreams@elite4.com', 'TEXT', '303 Dream Blvd', 'Celestic Town', 'SINNOH', 'Japan', 'S5J 2R4'),
    ('0a1b2c3d-4e5f-6a7b-8c9d-0e1f2a3b4c5d', 'Drayden', 'Shaga', 'dragon.master@opelucid.com', 'EMAIL', '404 Fang Ct', 'Opelucid City', 'UNOVA', 'United States', 'U3C 0V8'),
    ('6c7d8e9f-0a1b-2c3d-4e5f-6a7b8c9d0e1f', 'Candice', 'Suzuna', 'icy.trainer@snowpoint.com', 'PHONE', '505 Glacier Way', 'Snowpoint Temple', 'SINNOH', 'Japan', 'S1R 4P3'),
    ('5d6e7f8a-9b0c-1d2e-3f4a-5b6c7d8e9f0a', 'Brycen', 'Hachiku', 'icy.mask@icirrus.com', 'TEXT', '606 Frost Path', 'Icirrus Moor', 'UNOVA', 'United States', 'U3H 1S8'),
    ('1f2a3b4c-5d6e-7f8a-9b0c-1d2e3f4a5b6c', 'Volkner', 'Denzi', 'electrifying@sunyshore.com', 'EMAIL', '707 Beacon St', 'Sunyshore Lighthouse', 'SINNOH', 'Japan', 'S8W 1W5'),
    ('2f3a4b5c-6d7e-8f9a-0b1c-2d3e4f5a6b7c', 'Professor', 'Juniper', 'prof.juniper@unova-research.com', 'EMAIL', '123 Research Way', 'Nuvema Town', 'UNOVA', 'United States', 'U7Y 2X1'),
    ('3f4a5b6c-7d8e-9f0a-1b2c-3d4e5f6a7b8c', 'Cynthia', 'Shirona', 'champion@sinnoh-league.com', 'PHONE', '1 Champion Road', 'Pokémon League', 'SINNOH', 'Japan', 'S0A 1C1');

INSERT INTO customer_phonenumbers (customer_id, type, number)
VALUES
    (1, 'MOBILE', '212-555-1234'),
    (1, 'HOME', '212-555-5678'),
    (2, 'MOBILE', '813-555-2345'),
    (3, 'WORK', '347-555-3456'),
    (3, 'MOBILE', '347-555-7890'),
    (4, 'HOME', '81-555-4567'),
    (5, 'MOBILE', '516-555-5678'),
    (6, 'WORK', '81-555-6789'),
    (7, 'MOBILE', '718-555-7890'),
    (8, 'HOME', '81-555-8901'),
    (9, 'MOBILE', '917-555-9012'),
    (10, 'WORK', '81-555-0123'),
    (11, 'MOBILE', '908-555-7777'),
    (12, 'MOBILE', '81-555-9999');

INSERT INTO creatures (creature_id, registration_code, name, species, type, rarity, level, age, health, experience, status, strength, intelligence, agility, temperament)
VALUES
    ('8a4b5c6d-7e8f-9a0b-1c2d-3e4f5a6b7c8d', 'REG-AF45E78D', 'Spark', 'Electabuzz', 'ELECTRIC', 'RARE', 25, 3, 85, 4500, 'AVAILABLE', 70, 65, 80, 'FRIENDLY'),
    ('9b0c1d2e-3f4a-5b6c-7d8e-9f0a1b2c3d4e', 'REG-B2F19CA3', 'Ember', 'Charmeleon', 'FIRE', 'UNCOMMON', 18, 2, 75, 2800, 'AVAILABLE', 65, 60, 70, 'AGGRESSIVE'),
    ('0c1d2e3f-4a5b-6c7d-8e9f-0a1b2c3d4e5f', 'REG-C8D37E5B', 'Cascade', 'Vaporeon', 'WATER', 'RARE', 30, 4, 90, 5200, 'RESERVED', 75, 85, 65, 'DOCILE'),
    ('1d2e3f4a-5b6c-7d8e-9f0a-1b2c3d4e5f6a', 'REG-D9E48F6C', 'Terra', 'Torterra', 'GRASS', 'UNCOMMON', 22, 5, 95, 3800, 'AVAILABLE', 85, 55, 45, 'DOCILE'),
    ('2e3f4a5b-6c7d-8e9f-0a1b-2c3d4e5f6a7b', 'REG-E0F59G7D', 'Shadow', 'Gengar', 'GHOST', 'EPIC', 35, 7, 70, 6400, 'ADOPTION_PENDING', 60, 90, 80, 'PLAYFUL'),
    ('3f4a5b6c-7d8e-9f0a-1b2c-3d4e5f6a7b8c', 'REG-F1G60H8E', 'Mystic', 'Alakazam', 'PSYCHIC', 'EPIC', 40, 8, 65, 7800, 'RESERVED', 50, 100, 70, 'TIMID'),
    ('4a5b6c7d-8e9f-0a1b-2c3d-4e5f6a7b8c9d', 'REG-G2H71I9F', 'Boulder', 'Golem', 'ROCK', 'COMMON', 28, 12, 100, 4200, 'AVAILABLE', 95, 45, 35, 'AGGRESSIVE'),
    ('5b6c7d8e-9f0a-1b2c-3d4e-5f6a7b8c9d0e', 'REG-H3I82J0G', 'Freeze', 'Glaceon', 'ICE', 'RARE', 32, 3, 80, 5600, 'AVAILABLE', 65, 75, 85, 'FRIENDLY'),
    ('6c7d8e9f-0a1b-2c3d-4e5f-6a7b8c9d0e1f', 'REG-I4J93K1H', 'Wave', 'Oshawott', 'WATER', 'UNCOMMON', 15, 1, 70, 2000, 'ADOPTED', 55, 65, 75, 'FRIENDLY'),
    ('7d8e9f0a-1b2c-3d4e-5f6a-7b8c9d0e1f2a', 'REG-J5K04L2I', 'Splash', 'Piplup', 'WATER', 'LEGENDARY', 20, 2, 85, 3500, 'UNAVAILABLE', 60, 75, 70, 'TIMID'),
    ('8d9e0f1a-2b3c-4d5e-6f7a-8b9c0d1e2f3a', 'REG-K6L15M3J', 'Blaze', 'Infernape', 'FIRE', 'RARE', 36, 4, 88, 6200, 'ADOPTED', 90, 70, 95, 'AGGRESSIVE'),
    ('9e0f1a2b-3c4d-5e6f-7a8b-9c0d1e2f3a4b', 'REG-L7M26N4K', 'Leaf', 'Serperior', 'GRASS', 'RARE', 34, 5, 82, 5800, 'ADOPTED', 70, 85, 90, 'DOCILE'),
    ('a1b2c3d4-e5f6-a7b8-c9d0-e1f2a3b4c5d6', 'REG-M8N37O5L', 'Bolt', 'Zebstrika', 'ELECTRIC', 'UNCOMMON', 28, 3, 78, 4200, 'AVAILABLE', 75, 60, 85, 'FRIENDLY'),
    ('b2c3d4e5-f6a7-b8c9-d0e1-f2a3b4c5d6e7', 'REG-N9O48P6M', 'Psyche', 'Gothitelle', 'PSYCHIC', 'EPIC', 42, 6, 75, 7000, 'AVAILABLE', 55, 95, 65, 'TIMID'),
    ('c3d4e5f6-a7b8-c9d0-e1f2-a3b4c5d6e7f8', 'REG-O0P59Q7N', 'Phantom', 'Chandelure', 'GHOST', 'EPIC', 38, 5, 72, 6800, 'AVAILABLE', 60, 85, 60, 'PLAYFUL');

INSERT INTO trainings (training_id, training_code, name, description, difficulty, duration, status, category, price, location)
VALUES
    ('a9b8c7d6-e5f4-g3h2-i1j0-k9l8m7n6o5p4', 'TRN-12345678', 'Contest Basics', 'Fundamental training for creature performances and appeal displays', 'BEGINNER', 2, 'ACTIVE', 'CONTEST', 99.99, 'Nimbasa Musical Theater'),
    ('b8c7d6e5-f4g3-h2i1-j0k9-l8m7n6o5p4q3', 'TRN-23456789', 'Elemental Control', 'Learn to harness and control elemental powers', 'INTERMEDIATE', 4, 'ACTIVE', 'SPECIAL', 149.99, 'Celestic Town Ruins'),
    ('c7d6e5f4-g3h2-i1j0-k9l8-m7n6o5p4q3r2', 'TRN-34567890', 'Advanced Strikes', 'Strategic attack techniques for competitive battles', 'ADVANCED', 6, 'ACTIVE', 'ATTACK', 199.99, 'Battle Subway - Nimbasa City'),
    ('d6e5f4g3-h2i1-j0k9-l8m7-n6o5p4q3r2s1', 'TRN-45678901', 'Shield Training', 'Defensive maneuvers to improve durability and protection', 'INTERMEDIATE', 3, 'ACTIVE', 'DEFENSE', 129.99, 'Spear Pillar - Mt. Coronet'),
    ('e5f4g3h2-i1j0-k9l8-m7n6-o5p4q3r2s1t0', 'TRN-56789012', 'Psychic Development', 'Mental training to enhance psychic abilities', 'ADVANCED', 8, 'FULL', 'SPECIAL', 249.99, 'Abyssal Ruins - Undella Bay'),
    ('f4g3h2i1-j0k9-l8m7-n6o5-p4q3r2s1t0u9', 'TRN-67890123', 'Water Techniques', 'Specialized training for water-type creatures', 'INTERMEDIATE', 5, 'ACTIVE', 'SPECIAL', 179.99, 'Pastoria Great Marsh'),
    ('g3h2i1j0-k9l8-m7n6-o5p4-q3r2s1t0u9v8', 'TRN-78901234', 'Defensive Tactics', 'Focus on defensive strategies and endurance building', 'BEGINNER', 3, 'ACTIVE', 'DEFENSE', 119.99, 'Dragonspiral Tower - Ground Floor'),
    ('h2i1j0k9-l8m7-n6o5-p4q3-r2s1t0u9v8w7', 'TRN-89012345', 'Contest Performance', 'Training for exhibition and competition performances', 'BEGINNER', 4, 'ACTIVE', 'CONTEST', 139.99, 'Hearthome Contest Hall'),
    ('i1j0k9l8-m7n6-o5p4-q3r2-s1t0u9v8w7x6', 'TRN-90123456', 'Aerial Combat', 'Offensive aerial techniques for flying creatures', 'ADVANCED', 7, 'INACTIVE', 'ATTACK', 229.99, 'Mistralton Cargo Service'),
    ('j0k9l8m7-n6o5-p4q3-r2s1-t0u9v8w7x6y5', 'TRN-01234567', 'Legendary Potential', 'Exclusive training program for creatures with legendary potential', 'ADVANCED', 12, 'FULL', 'SPECIAL', 499.99, 'Hall of Origin - Sinnoh');

INSERT INTO adoptions (adoption_id, adoption_code, summary, total_adoptions, profile_creation_date, last_updated, profile_status, adoption_date, adoption_location, adoption_status, special_notes, customer_id, creature_id, training_id)
VALUES
    -- Burgh with 1 completed adoption
    ('k9l8m7n6-o5p4-q3r2-s1t0-u9v8w7x6y5z4', 'ADO-1A2B3C4D', 'Bug type lover', 1, '2023-01-15', NOW(), 'ACTIVE', '2023-02-01', 'Castelia City Adoption Center', 'COMPLETED', 'Inspiration for new artistic projects', '6f8d2e53-9b4c-48a7-91fe-c508dde7817a', '6c7d8e9f-0a1b-2c3d-4e5f-6a7b8c9d0e1f', 'a9b8c7d6-e5f4-g3h2-i1j0-k9l8m7n6o5p4'),
    -- Roark with pending adoption
    ('l8m7n6o5-p4q3-r2s1-t0u9-v8w7x6y5z4a3', 'ADO-2B3C4D5E', 'Mining companion', 0, '2023-02-20', NOW(), 'ACTIVE', '2023-03-05', 'Oreburgh Mine', 'PENDING', 'Needs help in the coal mines', 'a3b7c9d1-e5f0-4a2b-8c9d-0e1f2a3b4c5d', '9b0c1d2e-3f4a-5b6c-7d8e-9f0a1b2c3d4e', 'b8c7d6e5-f4g3-h2i1-j0k9-l8m7n6o5p4q3'),
    -- Elesa with approved adoption
    ('m7n6o5p4-q3r2-s1t0-u9v8-w7x6y5z4a3b2', 'ADO-3C4D5E6F', 'Runway partner', 3, '2023-01-10', NOW(), 'ACTIVE', '2023-03-15', 'Nimbasa Battle Subway', 'APPROVED', 'For fashion show performances', '7d8e9f0a-1b2c-3d4e-5f6a-7b8c9d0e1f2a', '0c1d2e3f-4a5b-6c7d-8e9f-0a1b2c3d4e5f', 'c7d6e5f4-g3h2-i1j0-k9l8-m7n6o5p4q3r2'),
    -- Maylene with pending adoption
    ('n6o5p4q3-r2s1-t0u9-v8w7-x6y5z4a3b2c1', 'ADO-4D5E6F7G', 'Training partner', 1, '2023-02-05', NOW(), 'ACTIVE', '2023-04-01', 'Veilstone Gym', 'PENDING', 'Needs sparring partner for martial arts', '2a3b4c5d-6e7f-8a9b-0c1d-2e3f4a5b6c7d', '1d2e3f4a-5b6c-7d8e-9f0a-1b2c3d4e5f6a', NULL),
    -- N with pending adoption
    ('o5p4q3r2-s1t0-u9v8-w7x6-y5z4a3b2c1d0', 'ADO-5E6F7G8H', 'Friend to creatures', 0, '2023-03-10', NOW(), 'ACTIVE', '2023-04-15', 'Dragonspiral Tower', 'PENDING', 'Believes in liberation and friendship', '8e9f0a1b-2c3d-4e5f-6a7b-8c9d0e1f2a3b', '2e3f4a5b-6c7d-8e9f-0a1b-2c3d4e5f6a7b', 'e5f4g3h2-i1j0-k9l8-m7n6-o5p4q3r2s1t0'),
    -- Caitlin with approved adoption
    ('p4q3r2s1-t0u9-v8w7-x6y5-z4a3b2c1d0e9', 'ADO-6F7G8H9I', 'Psychic companion', 2, '2023-01-25', NOW(), 'ACTIVE', '2023-03-20', 'Strange House', 'APPROVED', 'To enhance psychic abilities', '4c5d6e7f-8a9b-0c1d-2e3f-4a5b6c7d8e9f', '3f4a5b6c-7d8e-9f0a-1b2c-3d4e5f6a7b8c', 'f4g3h2i1-j0k9-l8m7-n6o5-p4q3r2s1t0u9'),
    -- Drayden with pending adoption
    ('q3r2s1t0-u9v8-w7x6-y5z4-a3b2c1d0e9f8', 'ADO-7G8H9I0J', 'Dragon keeper', 1, '2023-02-10', NOW(), 'ACTIVE', '2023-04-05', 'Opelucid Gym', 'PENDING', 'For dragon training excellence', '0a1b2c3d-4e5f-6a7b-8c9d-0e1f2a3b4c5d', '4a5b6c7d-8e9f-0a1b-2c3d-4e5f6a7b8c9d', 'g3h2i1j0-k9l8-m7n6-o5p4-q3r2s1t0u9v8'),
    -- Candice with cancelled adoption
    ('r2s1t0u9-v8w7-x6y5-z4a3-b2c1d0e9f8g7', 'ADO-8H9I0J1K', 'Ice type trainer', 0, '2023-03-01', NOW(), 'ACTIVE', '2023-05-01', 'Lake Acuity', 'CANCELLED', 'Gym renovations took priority', '6c7d8e9f-0a1b-2c3d-4e5f-6a7b8c9d0e1f', '5b6c7d8e-9f0a-1b2c-3d4e-5f6a7b8c9d0e', 'h2i1j0k9-l8m7-n6o5-p4q3-r2s1t0u9v8w7'),
    -- Brycen with returned adoption
    ('s1t0u9v8-w7x6-y5z4-a3b2-c1d0e9f8g7h6', 'ADO-9I0J1K2L', 'Movie co-star', 2, '2023-01-05', NOW(), 'SUSPENDED', '2023-02-15', 'Pokestar Studios', 'RETURNED', 'Creature did not enjoy acting', '5d6e7f8a-9b0c-1d2e-3f4a-5b6c7d8e9f0a', '8a4b5c6d-7e8f-9a0b-1c2d-3e4f5a6b7c8d', NULL),
    -- Volkner with cancelled adoption
    ('t0u9v8w7-x6y5-z4a3-b2c1-d0e9f8g7h6i5', 'ADO-0J1K2L3M', 'Electrical project', 4, '2023-02-25', NOW(), 'INACTIVE', '2023-04-20', 'Vista Lighthouse', 'CANCELLED', 'Too busy fixing Sunyshores blackouts', '1f2a3b4c-5d6e-7f8a-9b0c-1d2e3f4a5b6c', '7d8e9f0a-1b2c-3d4e-5f6a-7b8c9d0e1f2a', 'j0k9l8m7-n6o5-p4q3-r2s1-t0u9v8w7x6y5'),
    -- Professor Juniper with exactly 2 completed adoptions (max limit testing)
    ('u1v2w3x4-y5z6-a7b8-c9d0-e1f2g3h4i5j6', 'ADO-1K2L3M4N', 'Starter research', 2, '2023-02-01', NOW(), 'ACTIVE', '2023-03-01', 'Professor Junipers Lab', 'COMPLETED', 'For evolution research', '2f3a4b5c-6d7e-8f9a-0b1c-2d3e4f5a6b7c', '9e0f1a2b-3c4d-5e6f-7a8b-9c0d1e2f3a4b', 'b8c7d6e5-f4g3-h2i1-j0k9-l8m7n6o5p4q3'),
    ('v2w3x4y5-z6a7-b8c9-d0e1-f2g3h4i5j6k7', 'ADO-2L3M4N5O', 'Pokédex project', 2, '2023-02-01', NOW(), 'ACTIVE', '2023-04-10', 'Dreamyard', 'COMPLETED', 'For field research assistance', '2f3a4b5c-6d7e-8f9a-0b1c-2d3e4f5a6b7c', '8d9e0f1a-2b3c-4d5e-6f7a-8b9c0d1e2f3a', 'c7d6e5f4-g3h2-i1j0-k9l8-m7n6o5p4q3r2'),
    -- Champion Cynthia with exactly 2 completed adoptions (another max limit test)
    ('w3x4y5z6-a7b8-c9d0-e1f2-g3h4i5j6k7l8', 'ADO-3M4N5O6P', 'Championship team', 2, '2023-01-15', NOW(), 'ACTIVE', '2023-02-20', 'Sinnoh Pokémon League', 'COMPLETED', 'For championship battles', '3f4a5b6c-7d8e-9f0a-1b2c-3d4e5f6a7b8c', 'b2c3d4e5-f6a7-b8c9-d0e1-f2a3b4c5d6e7', 'e5f4g3h2-i1j0-k9l8-m7n6-o5p4q3r2s1t0'),
    ('x4y5z6a7-b8c9-d0e1-f2g3-h4i5j6k7l8m9', 'ADO-4N5O6P7Q', 'Mythology research', 2, '2023-01-15', NOW(), 'ACTIVE', '2023-03-10', 'Celestic Town Ruins', 'COMPLETED', 'For ancient legends research', '3f4a5b6c-7d8e-9f0a-1b2c-3d4e5f6a7b8c', 'c3d4e5f6-a7b8-c9d0-e1f2-a3b4c5d6e7f8', 'j0k9l8m7-n6o5-p4q3-r2s1-t0u9v8w7x6y5');