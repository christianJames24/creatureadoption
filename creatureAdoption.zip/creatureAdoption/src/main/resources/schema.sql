CREATE TABLE customers (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           customer_id VARCHAR(36) NOT NULL UNIQUE,
                           first_name VARCHAR(100) NOT NULL,
                           last_name VARCHAR(100) NOT NULL,
                           email_address VARCHAR(255) NOT NULL,
                           contact_method_preference VARCHAR(10) NOT NULL,
                           street_address VARCHAR(255) NOT NULL,
                           city VARCHAR(100) NOT NULL,
                           province VARCHAR(100) NOT NULL,
                           country VARCHAR(100) NOT NULL,
                           postal_code VARCHAR(20) NOT NULL
);
CREATE TABLE customer_phonenumbers (
                                       id INT AUTO_INCREMENT PRIMARY KEY,
                                       customer_id INT NOT NULL,
                                       type VARCHAR(20) NOT NULL,
                                       number VARCHAR(20) NOT NULL,
                                       FOREIGN KEY (customer_id) REFERENCES customers(id)
);


--------creatures
CREATE TABLE creatures (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           creature_id VARCHAR(36) NOT NULL UNIQUE,
                           registration_code VARCHAR(15) NOT NULL UNIQUE,
                           name VARCHAR(50) NOT NULL,
                           species VARCHAR(50) NOT NULL,
                           type VARCHAR(20) NOT NULL,
                           rarity VARCHAR(20) NOT NULL,
                           level INT NOT NULL,
                           age INT NOT NULL,
                           health INT NOT NULL,
                           experience INT NOT NULL,
                           status VARCHAR(20) NOT NULL,
                           strength INT NOT NULL,
                           intelligence INT NOT NULL,
                           agility INT NOT NULL,
                           temperament VARCHAR(20) NOT NULL
);

CREATE TABLE trainings (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           training_id VARCHAR(36) NOT NULL UNIQUE,
                           training_code VARCHAR(15) NOT NULL UNIQUE,
                           name VARCHAR(100) NOT NULL,
                           description TEXT NOT NULL,
                           difficulty VARCHAR(20) NOT NULL,
                           duration INT NOT NULL,
                           status VARCHAR(20) NOT NULL,
                           category VARCHAR(20) NOT NULL,
                           price DECIMAL(10, 2) NOT NULL,
                           location VARCHAR(100) NOT NULL
);

CREATE TABLE adoptions (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           adoption_id VARCHAR(36) NOT NULL UNIQUE,
                           adoption_code VARCHAR(15) NOT NULL UNIQUE,
                           summary VARCHAR(255) NOT NULL,
                           total_adoptions INT,
                           profile_creation_date DATE NOT NULL,
                           last_updated TIMESTAMP NOT NULL,
                           profile_status VARCHAR(20) NOT NULL,
                           adoption_date DATE,
                           adoption_location VARCHAR(100),
                           adoption_status VARCHAR(20) NOT NULL,
                           special_notes TEXT,
                           customer_id VARCHAR(36) NOT NULL,
                           creature_id VARCHAR(36) NOT NULL,
                           training_id VARCHAR(36)
);