package com.lee.creatureAdoption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreatureAdoptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
